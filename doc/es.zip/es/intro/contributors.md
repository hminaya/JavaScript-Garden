## Contributors

 - [Caio Romão][1] (Spelling corrections)
 - [Andreas Blixt][2] (Language corrections)

[1]: https://github.com/caio
[2]: https://github.com/blixt

