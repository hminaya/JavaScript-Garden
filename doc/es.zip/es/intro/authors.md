## The Authors

This guide is the work of two lovely Stack Overflow users, [Ivo Wetzel][1]
(Writing) and [Zhang Yi Jiang][2] (Design).

[1]: http://stackoverflow.com/users/170224/ivo-wetzel
[2]: http://stackoverflow.com/users/313758/yi-jiang

