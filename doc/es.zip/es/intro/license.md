## License

JavaScript Garden is published under the [MIT license][1] and hosted on
[GitHub][2]. If you find errors or typos please [file an issue][3] or a pull 
request on the repository. You can also find us in the [JavaScript room][4] on
Stack Overflow chat. 

[1]: https://github.com/BonsaiDen/JavaScript-Garden/blob/next/LICENSE
[2]: https://github.com/BonsaiDen/JavaScript-Garden
[3]: https://github.com/BonsaiDen/JavaScript-Garden/issues
[4]: http://chat.stackoverflow.com/rooms/17/javascript

